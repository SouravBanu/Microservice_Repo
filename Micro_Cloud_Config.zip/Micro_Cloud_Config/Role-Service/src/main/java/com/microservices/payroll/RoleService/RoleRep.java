package com.microservices.payroll.RoleService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRep extends JpaRepository<Role, Long> {
//public Role findbyRoleID(String roleName);

}
