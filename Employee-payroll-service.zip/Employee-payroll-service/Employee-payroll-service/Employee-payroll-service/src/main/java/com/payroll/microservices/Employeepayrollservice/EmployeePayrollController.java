package com.payroll.microservices.Employeepayrollservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class EmployeePayrollController {
	@Autowired
	EmployeeServiceDemo employeeServiceDemo;
	
	@Autowired
	EmployeePayrollRepo employeePayrollRepo;

	
	@PostMapping("/employee/{empID}/role/{roleID}")
	public void insertPayrollInfo(@PathVariable Long empID,@PathVariable Long roleID) {
		
		//insert
		//System.out.println("Test");
		//EmployeePayroll employeePayroll = new EmployeePayroll(10L,100L,"AAA","BBB",101L,"HR","Human Resource");
		//ResponseEntity<EmployeePayroll> employeeEntity = new RestTemplate().getForEntity("http://localhost:8081/employee/{empID}",EmployeePayroll.class,empID );
		//EmployeePayroll employeePayroll = employeeEntity.getBody();
		EmployeePayroll employeePayroll = employeeServiceDemo.getEmpDetails(empID);
		ResponseEntity<EmployeePayroll> roleEntity = new RestTemplate().getForEntity("http://localhost:8081/employee/{empID}",EmployeePayroll.class,empID );
		employeePayroll.setRoleID(roleEntity.getBody().getRoleID());
		employeePayroll.setRoleName(roleEntity.getBody().getRoleName());
		employeePayroll.setRoleDes(roleEntity.getBody().getRoleDes());
		employeePayrollRepo.save(employeePayroll);
	}
	@GetMapping("/employee/{empID}")
	public EmployeePayroll displayEmployeeInfo(@PathVariable Long empID) {
		
		//insert
		return new EmployeePayroll(10L,100L,"AAA","BBB",101L,"HR","Human Resource");
		
		
	}

}
