package com.payroll.microservices.zuuledgeserver;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulEdgeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
