package com.microservices.payroll.RoleService;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoleServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
