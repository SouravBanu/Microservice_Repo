package com.microservices.payroll.RoleService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoleController {
	private static Logger log=LoggerFactory.getLogger(RoleController.class);
	@Autowired
	RoleRep roleRepo; 
	
	@GetMapping("/role/{roleID}")
	public Role getEmpDetails(@PathVariable Long roleID) {
		log.info("Inside getEmpDetails");
		//return new Employee("AAA","BBB",1234L,new Date());
		//if (employeeRepo.findOne(empID) != null) {
			return roleRepo.findOne(roleID);
		 //Role role = roleRepo.findbyRoleID("HR");
		 //return role;
		//else
			//return 'Not Found";
				
			
		//}
		
	}

}
