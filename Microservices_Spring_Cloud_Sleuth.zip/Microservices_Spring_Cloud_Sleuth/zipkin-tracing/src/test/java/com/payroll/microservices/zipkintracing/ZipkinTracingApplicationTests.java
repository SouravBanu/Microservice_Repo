package com.payroll.microservices.zipkintracing;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinTracingApplicationTests {

	@Test
	void contextLoads() {
	}

}
