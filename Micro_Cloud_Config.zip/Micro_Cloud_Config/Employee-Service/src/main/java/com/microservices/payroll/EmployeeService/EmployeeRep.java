package com.microservices.payroll.EmployeeService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRep extends JpaRepository<Employee, Long> {

}
