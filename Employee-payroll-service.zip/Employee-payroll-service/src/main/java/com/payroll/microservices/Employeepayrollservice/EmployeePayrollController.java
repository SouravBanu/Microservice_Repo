package com.payroll.microservices.Employeepayrollservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeePayrollController {
	@Autowired
	EmployeePayrollRepo employeePayrollRepo;
	
	@PostMapping("/employee/{empID}/role/{roleID}")
	public void insertPayrollInfo(@PathVariable Long empID,@PathVariable Long roleID) {
		
		//insert
		System.out.println("Test");
		EmployeePayroll employeePayroll = new EmployeePayroll(10L,100L,"AAA","BBB",101L,"HR","Human Resource");
		employeePayrollRepo.save(employeePayroll);
	}
	@GetMapping("/employee/{empID}")
	public EmployeePayroll displayEmployeeInfo(@PathVariable Long empID) {
		
		//insert
		return new EmployeePayroll(10L,100L,"AAA","BBB",101L,"HR","Human Resource");
		
	}

}
