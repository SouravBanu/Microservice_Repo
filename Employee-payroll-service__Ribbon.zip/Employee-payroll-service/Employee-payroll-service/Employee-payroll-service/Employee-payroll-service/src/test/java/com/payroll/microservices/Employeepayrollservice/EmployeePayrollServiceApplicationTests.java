package com.payroll.microservices.Employeepayrollservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePayrollServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
