package com.microservices.payroll.EmployeeService;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@EnableHystrix
public class EmployeeController {
	private static Logger log=LoggerFactory.getLogger(EmployeeController.class);
	@Autowired
	EmployeeRep employeeRepo;
	@Autowired
	Environment environment;
	
	@GetMapping("/employee/{empID}")
	public Employee getEmpDetails(@PathVariable Long empID) {
		log.info("Inside getEmpDetails");
		//return new Employee("AAA","BBB",1234L,new Date());
		//if (employeeRepo.findOne(empID) != null) {
		Employee employee = employeeRepo.findOne(empID);
		employee.setPort(Integer.parseInt(environment.getProperty("local.server.port")));
			return employee;
		//else
			//return 'Not Found";
				
			
		//}
		
	}
	@GetMapping("/employee/fault-tolerance")
	@HystrixCommand(fallbackMethod="fallbackEmployeeDetails")
	public Employee getEmpDetailsFaultTolerance() {
		throw new RuntimeException("Some Exception"); 
	}
	public Employee fallbackEmployeeDetails() {
		return new Employee("First Name","Last Name",101L,new Date());
	}
}
