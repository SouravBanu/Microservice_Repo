package com.payroll.microservices.Employeepayrollservice;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeePayrollController {
	EmployeePayrollRepo employeePayrollRepo;
	@PostMapping("/employee/{empID}/role/{roleID}")
	public void insertPayrollInfo(@PathVariable Long empID,@PathVariable Long roleID) {
		
		//insert
	}

}
