package com.test.SpringBoot_Demo;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.test.controller.HomeController;

/**
 * Unit test for simple App.
 */

public class AppTest{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
	@Test
    public void TestApp(  )
    {
        HomeController hc = new HomeController();
        String result= hc.home();
        assertEquals(result, " Hello All !!! This is my first Spring Boot App");
    }

   
}
