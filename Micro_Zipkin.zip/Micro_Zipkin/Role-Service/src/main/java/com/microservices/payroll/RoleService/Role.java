package com.microservices.payroll.RoleService;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Role {
	@Column(name="role_name")
	private String roleName;
	@Column(name="role_des")
	private String roleDes;
	@Id
	@Column(name="role_id")
	private Long roleID;

	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Role(String roleName, String roleDes, Long roleID) {
		super();
		this.roleName = roleName;
		this.roleDes = roleDes;
		this.roleID = roleID;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDes() {
		return roleDes;
	}

	public void setRoleDes(String roleDes) {
		this.roleDes = roleDes;
	}

	public Long getRoleID() {
		return roleID;
	}

	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}
	

	
	

}
