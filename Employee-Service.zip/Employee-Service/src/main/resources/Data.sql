insert into employee( emp_id,first_name,last_name,date_of_birth) values(1000,'AAAA','BBBB',sysdate());
insert into employee( emp_id,first_name,last_name,date_of_birth) values(1001,'XXXX','CCCC',sysdate());
insert into employee( emp_id,first_name,last_name,date_of_birth) values(1002,'YYYY','DDDD',sysdate());
insert into employee( emp_id,first_name,last_name,date_of_birth) values(1003,'ZZZZ','EEEE',sysdate());