package com.payroll.microservices.Employeepayrollservice;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name="employee-service",url="localhost:8081")
@FeignClient(name="employee-service")
@RibbonClient(name="employee-service")
public interface EmployeeServiceDemo {

	@GetMapping("/employee/{empID}")
	public EmployeePayroll getEmpDetails(@PathVariable("empID") Long empID);
}
