package com.test.controller;



import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.test.model.*;

@RestController
@RequestMapping("api/v1")
public class ShireckController {
	@RequestMapping( value="shipwreck", method=RequestMethod.GET)
	public List<Shipwreck> list(){
		return ShipwreckStub.list();
	}

}
