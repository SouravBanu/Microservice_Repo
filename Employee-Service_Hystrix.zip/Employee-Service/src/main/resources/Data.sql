insert into employee( emp_id,first_name,last_name,date_of_birth,port) values(1000,'AAAA','BBBB',sysdate(),0);
insert into employee( emp_id,first_name,last_name,date_of_birth,port) values(1001,'XXXX','CCCC',sysdate(),0);
insert into employee( emp_id,first_name,last_name,date_of_birth,port) values(1002,'YYYY','DDDD',sysdate(),0);
insert into employee( emp_id,first_name,last_name,date_of_birth,port) values(1003,'ZZZZ','EEEE',sysdate(),0);