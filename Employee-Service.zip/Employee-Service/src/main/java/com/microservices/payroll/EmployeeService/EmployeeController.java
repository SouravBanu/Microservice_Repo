package com.microservices.payroll.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeRep employeeRepo; 
	
	@GetMapping("/employee/{empID}")
	public Employee getEmpDetails(@PathVariable Long empID) {
		//return new Employee("AAA","BBB",1234L,new Date());
		//if (employeeRepo.findOne(empID) != null) {
			return employeeRepo.findOne(empID);
		//else
			//return 'Not Found";
				
			
		//}
		
	}

}
