package com.payroll.microservices.Employeepayrollservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmployeePayroll {
	@Id
	@Column(name="payroll_ID")
	private Long payrollID;
	@Column(name="emp_ID")
	private Long empID;
	@Column(name="first_Name")
	private String firstName;
	@Column(name="last_Name")
	private String lastName;
	@Column(name="role_ID")
	private Long roleID;
	@Column(name="role_Name")
	private String roleName;
	@Column(name="role_Des")
	private String roleDes;
	public EmployeePayroll() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeePayroll(Long payrollID, Long empID, String firstName, String lastName, Long roleID, String roleName,
			String roleDes) {
		super();
		this.payrollID = payrollID;
		this.empID = empID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.roleID = roleID;
		this.roleName = roleName;
		this.roleDes = roleDes;
	}
	public Long getPayrollID() {
		return payrollID;
	}
	public void setPayrollID(Long payrollID) {
		this.payrollID = payrollID;
	}
	public Long getEmpID() {
		return empID;
	}
	public void setEmpID(Long empID) {
		this.empID = empID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getRoleID() {
		return roleID;
	}
	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getRoleDes() {
		return roleDes;
	}
	public void setRoleDes(String roleDes) {
		this.roleDes = roleDes;
	}
	
	

}
