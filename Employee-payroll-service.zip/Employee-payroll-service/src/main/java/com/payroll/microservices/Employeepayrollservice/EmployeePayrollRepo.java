package com.payroll.microservices.Employeepayrollservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeePayrollRepo extends JpaRepository<EmployeePayroll, Long> {

}
