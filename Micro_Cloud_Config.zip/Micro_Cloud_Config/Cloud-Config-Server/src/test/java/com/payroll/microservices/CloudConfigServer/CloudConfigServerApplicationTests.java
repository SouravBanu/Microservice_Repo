package com.payroll.microservices.CloudConfigServer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
