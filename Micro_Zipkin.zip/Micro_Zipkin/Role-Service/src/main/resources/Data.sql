insert into role( role_id,role_name,role_des) values(100,'HR','BBBB');
insert into role( role_id,role_name,role_des) values(101,'Admin','CCCC');
insert into role( role_id,role_name,role_des) values(102,'SE','DDDD');
insert into role( role_id,role_name,role_des) values(103,'Cleaner','EEEE');